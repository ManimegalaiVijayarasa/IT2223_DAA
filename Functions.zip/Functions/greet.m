

function greet(name)
    disp(['Hello ',name]);
end

% greet('Manimegalai..')