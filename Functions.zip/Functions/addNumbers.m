
function sum = addNumbers(x,y)  % save with function name
        sum = x+y;
end

% addNumbers(6,2)