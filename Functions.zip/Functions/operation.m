% This function for input and multiple outputs


function [add,sub,mul] = operation (a,b)
     add = a+b;
     sub = a-b;
     mul = a*b;

end

% [add,sub,mul] = operation(5,6)